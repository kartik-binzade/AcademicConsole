from django.apps import AppConfig


class NoticeboardConfig(AppConfig):
    name = 'noticeboard'
