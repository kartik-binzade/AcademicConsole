from django.apps import AppConfig


class Year1Config(AppConfig):
    name = 'year1'
