This folder contains the screenshots.
