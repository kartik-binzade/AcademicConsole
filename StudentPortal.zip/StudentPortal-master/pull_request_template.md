### All Submissions:

* [ ] Have you followed the guidelines in our Contributing document?

### New Feature Submissions:

1. [ ] Does your submission pass build tests locally?
2. [ ] Have you indented your code locally prior to submission?

### Changes to Core Features:

* [ ] Have you added an explanation of what your changes do and why you'd like us to include them?
* [ ] Have you successfully ran tests with your changes locally?
